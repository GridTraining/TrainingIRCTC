﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public const int minlen = 10;
        public const int maxlen = 10;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == true)
            {


                comboBox2.ResetText();

            }

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void domainUpDown1_SelectedItemChanged(object sender, EventArgs e)
        {
            ;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint_1(object sender, PaintEventArgs e)
        {

        }

        /*  private void textBox1_TextChanged(object sender, EventArgs e)
          {

              String st = textBox1.Text.ToString();

              if (String.IsNullOrEmpty(textBox1.Text) || String.IsNullOrWhiteSpace(textBox1.Text))
              {
                  button1.Enabled = false;
                  errorProvider1.SetError(textBox1, "enter your name");
                  errorProvider2.SetError(textBox1, "");
                  errorProvider3.SetError(textBox1, "");



              }
              else
              {
                  errorProvider1.SetError(textBox1, "");
                  errorProvider2.SetError(textBox1, "");
                  errorProvider3.SetError(textBox1, "correct");
                  button1.Enabled = true;

              }


          }*/

        private void button1_Click(object sender, EventArgs e)
        {

            String st = textBox1.Text.ToString();
            String st1 = textBox2.Text.ToString();

            var sp = new string(st.Where(c => Char.IsLetter(c)
                                               || Char.IsWhiteSpace(c)).ToArray());
            var sp1 = new string(st1.Where(d => Char.IsLetter(d)
                                             || Char.IsWhiteSpace(d)).ToArray());
            if (st != sp)
            {
                MessageBox.Show("invalid");
                textBox1.ResetText();

            }
            else if (st1 != sp1)
            {
                MessageBox.Show("invalid");
                textBox2.ResetText();
            }

            else { }



            if (comboBox1.SelectedIndex > -1)
            {

            }
            else
            {
                MessageBox.Show("please select class");
                button1.Enabled = false;
            }
          
            if(comboBox3.SelectedIndex >-1)
            {
                button1.Enabled = true;
            }
            else
            {
                MessageBox.Show("please select gender");
                button1.Enabled = false;

            }
            if(String.IsNullOrEmpty(textBox3.Text)||String.IsNullOrWhiteSpace(textBox3.Text
                ))
            {
                button1.Enabled = false;
            }
            else
            {
                button1.Enabled = true;
            }
           
            if (textBox5.TextLength < minlen)
            {
                MessageBox.Show("less than minimum lenght");
            }
            if (textBox5.TextLength > maxlen)
            {
                MessageBox.Show("more than maximum lenght");
            }
            /* if (textBox5.TextLength >= minlen && textBox5.TextLength <= maxlen)
             {


             }*/
            if (comboBox5.SelectedIndex > -1)
            {


            }
            else
            {
                MessageBox.Show("please select IDcard type");

            }


        }


        private void enter(object sender, EventArgs e)
        {
            textBox1.BackColor = Color.White;
        }

        private void leave(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(textBox1.Text) || String.IsNullOrWhiteSpace(textBox1.Text))
            {
                button1.Enabled = false;
                textBox1.BackColor = Color.Red;


            }
            else
            {
                button1.Enabled = true;
                textBox1.BackColor = Color.White;

            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_Enter(object sender, EventArgs e)
        {
            textBox2.BackColor = Color.White;
        }

        private void textBox2_leave(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(textBox1.Text) || String.IsNullOrWhiteSpace(textBox1.Text))
            {
                button1.Enabled = false;
               textBox2.BackColor = Color.Red;
                
            }
            else
            {
                button1.Enabled = true;
               

                textBox2.BackColor = Color.White;

            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (comboBox2.Enabled == true)
            {
                checkBox1.Checked = false;
            }

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
           

        }

        private void texbox(object sender, CancelEventArgs e)
        {

        }

        

       

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(textBox1.Text) || String.IsNullOrWhiteSpace(textBox1.Text))
            {
                button1.Enabled = false;
                 textBox1.BackColor = Color.Red;
              
            }
            else
            {
                button1.Enabled = true;
                textBox1.BackColor = Color.White;
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dateTimePicker1.MinDate = DateTime.Now.Date;
            String date = dateTimePicker1.MinDate.ToString("yyyy-MM-dd");
            MessageBox.Show(date);


        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(textBox4.Text) || String.IsNullOrWhiteSpace(textBox4.Text))
            {
                button1.Enabled = false;
            }
            else
            {
                button1.Enabled = true;
                String txt = textBox4.Text.ToString();
                var txt1 = new string(txt.Where(c => Char.IsDigit(c)).ToArray());

                if (txt != txt1)
                {
                    MessageBox.Show("please enter correct age");
                    textBox4.ResetText();
                }
                else if(txt==txt1)
                {
                    int txt2 = Convert.ToInt32(txt);
                        
                        if(txt2==0)
                        {
                            MessageBox.Show("please enter correct age");
                            textBox4.ResetText();
                        }
                        else if(txt2>= 60)
                        {
                            MessageBox.Show("please enter correct age less than 60");
                            textBox4.ResetText();

                        }
                    }
                }
            }
            
            


        

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
           
        String txt2 = textBox5.Text.ToString();
                var txt3 = new string(txt2.Where(c => Char.IsDigit(c)).ToArray());

                if (txt2 != txt3)
                {
                    MessageBox.Show("please enter valid 10 digit phone no.");
                    textBox5.ResetText();
                }
                

        
    }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }
    }
}